from django.contrib import admin
from price.models import Developer

# Register your models here.
admin.site.register(Developer)